<?php
/**
 * Fallback implementations of helper functions that used to live in the old
 * (external, MySQL-era) config/func.php + config/global.php. Those files are
 * outside this workspace and weren't available during the Postgres migration,
 * so these are safe, best-effort stand-ins guarded by function_exists() —
 * if the real legacy helpers are already loaded elsewhere, these no-op.
 */

if (!function_exists('err_log')) {
    function err_log($msg, $file = null)
    {
        error_log(($file ? '[' . $file . '] ' : '') . (is_scalar($msg) ? $msg : print_r($msg, true)));
    }
}

if (!function_exists('url_cooker')) {
    function url_cooker($str)
    {
        $slug = strtolower(trim((string)$str));
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        return trim($slug, '-');
    }
}

if (!function_exists('to_url')) {
    function to_url($str)
    {
        return url_cooker($str);
    }
}

if (!function_exists('url2mysql')) {
    function url2mysql($str)
    {
        return str_replace('-', ' ', (string)$str);
    }
}

if (!function_exists('getPropertyType')) {
    function getPropertyType($type_own_srch)
    {
        $t = strtolower((string)$type_own_srch);
        if (strpos($t, 'condo') !== false || strpos($t, 'apartment') !== false || strpos($t, 'co-op') !== false || strpos($t, 'co-ownership') !== false) {
            return 'condo';
        }
        if (strpos($t, 'town') !== false) {
            return 'townhouse';
        }
        if (strpos($t, 'semi') !== false) {
            return 'semi';
        }
        return 'house';
    }
}

// Local image mirroring is gone; kept only so old call sites don't fatal.
if (!function_exists('get_path_form_mln')) {
    function get_path_form_mln($ml_num)
    {
        return '';
    }
}

if (!function_exists('hDays')) {
    function hDays($today, $updated)
    {
        try {
            $a = new DateTime($today);
            $b = new DateTime($updated ?: $today);
            return $a->diff($b);
        } catch (Exception $e) {
            return new DateInterval('P0D');
        }
    }
}

if (!function_exists('verifyFormToken')) {
    function verifyFormToken($name)
    {
        return isset($_POST[$name]) && $_POST[$name] !== '';
    }
}

if (!function_exists('bd_nice_number')) {
    function bd_nice_number($value)
    {
        return '$' . number_format((float)$value, 0);
    }
}

// Degrades gracefully to "no clustering" (one marker per listing) if the
// original marker-clustering algorithm isn't available.
if (!function_exists('cluster')) {
    function cluster($markers, $px, $zoom)
    {
        return $markers;
    }
}

// money_format() was removed in PHP 8.0; this covers the '%.0n' usage
// (locale currency, no decimals) found throughout the templates.
if (!function_exists('money_format')) {
    function money_format($format, $number)
    {
        return '$' . number_format((float)$number, 0);
    }
}
