
<?php
define( 'INCLUDE_DIR', dirname( __FILE__ ) . '/' );
require_once 'vendor/autoload.php';
require_once '../config/config.php';
require_once '../config/func.php';
require_once 'signup/includes/functions.php';
require_once 'signup/includes/main.php';
header('Cache-Control: max-age=900');

 function get_community_latlon($municipality,$community ){
    global $mysqli;
    $query = "select lat,lon,municipality,community from URL_MAPPER where municipality_url = ? and community_url = ? and record_type='community';  "  ;
    err_log($query.":".$municipality.":".$community);
    if ($stmt = $mysqli->prepare($query)){
        $stmt->bind_param("ss",$municipality,$community);
        $stmt->execute();
        $result = $stmt->get_result();
        #print_r( $result);
       if ($row = $result->fetch_assoc()) {
           $escapedListing= array_map(array($mysqli, 'real_escape_string'), $row);
           extract($escapedListing);
           print($query.":>".$escapedListing."<:".$lat.": ".$lon);
           if( !(empty($lon) || empty( $lat)) ){
                          $stmt->close();
                           return array($lat,$lon,$municipality,$community);
           } else {
                           return array();
           }
       }
    }
 }
print_r(get_community_latlon('toronto','mimico') );
?>
