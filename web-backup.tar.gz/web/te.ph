
<?php
define( 'INCLUDE_DIR', dirname( __FILE__ ) . '/' );
require_once 'vendor/autoload.php';
require_once '../config/config.php';
require_once '../config/func.php';
require_once 'signup/includes/functions.php';
require_once 'signup/includes/main.php';
require_once '../config/global.php';
header('Cache-Control: max-age=900');

